
from flask import Flask, request, jsonify, send_from_directory
import pandas as pd
import os

app = Flask(__name__)

# Carpeta donde se guardarán los archivos subidos
UPLOAD_FOLDER = './uploads'
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ruta para subir los archivos Excel
@app.route('/upload', methods=['POST'])
def upload_files():
    file1 = request.files.get('file1')
    file2 = request.files.get('file2')

    if not file1 or not file2:
        return jsonify({"error": "Faltan archivos"}), 400

    file1.save(os.path.join(app.config['UPLOAD_FOLDER'], file1.filename))
    file2.save(os.path.join(app.config['UPLOAD_FOLDER'], file2.filename))

    try:
        df1 = pd.read_excel(os.path.join(app.config['UPLOAD_FOLDER'], file1.filename))
        df2 = pd.read_excel(os.path.join(app.config['UPLOAD_FOLDER'], file2.filename))
        
        resultado = {
            "indicador1": df1.iloc[:, 0].sum(),  # Ejemplo básico de procesamiento
            "indicador2": df2.iloc[:, 0].mean(),
        }

        return jsonify({"mensaje": "Archivos procesados correctamente", "resultado": resultado})
    
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

if __name__ == '__main__':
    app.run(debug=True)
